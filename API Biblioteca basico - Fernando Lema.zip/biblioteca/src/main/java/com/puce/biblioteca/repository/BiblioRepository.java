package com.puce.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.puce.biblioteca.model.Biblio;
import org.springframework.stereotype.Repository;

public interface BiblioRepository extends JpaRepository<Biblio, Integer>{
}