package com.puce.biblioteca.service;
import com.puce.biblioteca.controller.BiblioController;
import com.puce.biblioteca.model.Biblio;
import com.puce.biblioteca.repository.BiblioRepository;
import org.springframework.stereotype.Service;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BiblioService {
    private BiblioRepository biblioRepository;

    public BiblioService(BiblioRepository biblioRepository){
        this.biblioRepository = biblioRepository;
    }

    //TODO
    public List <Biblio> traerTodos(){
        return biblioRepository.findAll();
    }

    //TRAER UNO
    public Optional <Biblio> traerUno(int id){
        return biblioRepository.findById(id);
    }

    // GUARDAR
    public Biblio guardar (Biblio biblio){
        return biblioRepository.save(biblio);
    }

    // EDITAR
    public Optional <Biblio> editar(int id, Biblio Biblioactualizada){
        return biblioRepository.findById(id)
                .map(biblioExiste ->{
                    biblioExiste.setTitulo(Biblioactualizada.getTitulo());
                    biblioExiste.setAnio(Biblioactualizada.getAnio());
                    return biblioRepository.save(biblioExiste);
                });
    }

    // ELIMINAR
    public boolean eliminar (int id){
        if (biblioRepository.existsById(id)){
            biblioRepository.deleteById(id);
            return true;
        }else{
            return false;
        }
    }
}
