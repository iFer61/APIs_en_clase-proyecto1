package com.puce.biblioteca.controller;

import com.puce.biblioteca.model.Biblio;
import com.puce.biblioteca.service.BiblioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/biblioteca")
public class BiblioController {

    private BiblioService biblioService;

    public BiblioController( BiblioService biblioService){
        this.biblioService = biblioService;
    }

    //TODOS
    @GetMapping
    public List<Biblio> verTodos(){
        return biblioService.traerTodos();
    }

    //TRAER UNO
    @GetMapping("/{id}")
    public ResponseEntity<Biblio> traerUno(@PathVariable int id){
        return biblioService.traerUno(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // GUARDAR
    @PostMapping
    public ResponseEntity<Biblio> guardar(@RequestBody Biblio biblio){
        Biblio nuevaBiblio = biblioService.guardar(biblio);
        return new ResponseEntity<>(nuevaBiblio, HttpStatus.CREATED);
    }

    // EDITAR
    @PutMapping("/{id}")
    public ResponseEntity<Biblio> editar(@PathVariable int id, @RequestBody Biblio biblio){
        return biblioService.editar(id, biblio)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ELIMINAR
    @DeleteMapping("/{id}")
    public ResponseEntity <Biblio> eliminar (@PathVariable int id){
        if (biblioService.eliminar(id)){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}
